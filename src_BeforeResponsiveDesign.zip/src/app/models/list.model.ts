export class List {
    _id:string | undefined;
    title: string | undefined;
}