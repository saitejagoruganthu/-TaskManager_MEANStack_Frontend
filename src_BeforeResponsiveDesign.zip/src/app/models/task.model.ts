export class Task {
    _id:string | undefined;
    title: string | undefined;
    _listId:string | undefined;
    completed:boolean | undefined
}